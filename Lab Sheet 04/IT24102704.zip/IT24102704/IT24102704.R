setwd("C:/Users/it24102704/Desktop/IT24102704")


branch_data <- read.table("Exercise.txt",head =TRUE,sep = ",")


fix(branch_data)


head(branch_data)



attach(branch_data)

#
str(branch_data)


summary(branch_data)

#
boxplot(branch_data$Sales_X1, outline = TRUE, outpch = 8, horizontal=TRUE,main= "Sales Distribution")
#

summary(branch_data$Advertising_X2)


IQR(branch_data$Advertising_X2)

#

outliers <- function(years){
  Q1 <- quantile(years)[2]
  Q3 <- quantile(years)[4]
  iqr <- Q3-Q1
  
  lb <- Q1 - 1.5*iqr
  ub <- Q3 + 1.5*iqr
  
  outliers <- years[years < lb | years > ub]
  
  outliers = sort(outliers)
  
  print(paste("Upper Bound : " , ub))
  print(paste("Lower Bound : " , lb))
  print(paste("IQR : ",iqr))
  print(paste("outliers: ", paste(outliers, collapse=",")))
}


outliers(branch_data$Years_X3)